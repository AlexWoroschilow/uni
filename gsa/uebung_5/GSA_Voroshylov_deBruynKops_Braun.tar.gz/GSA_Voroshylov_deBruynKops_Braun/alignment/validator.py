class Validator:
    
    def __init__(self):
        return None
    
    def seq1(self, seq):
        return None
    
    def seq2(self, seq):
        return None
    
    def alg(self, alg):
        return None
    
    def is_erlaubt(self, type, count):
        return True
